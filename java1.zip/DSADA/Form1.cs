using System;
using System.Text;
using System.Windows.Forms;

namespace INF._04_01_23._01_SG
{
    public partial class Form1 : Form
    {
        private string aktualneHaslo = string.Empty;

        public Form1()
        {
            InitializeComponent();
        }

        private void generuj_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(znaki.Text, out int ileZnakow) || ileZnakow <= 0)
            {
                MessageBox.Show("Wprowadź poprawną dodatnią liczbę znaków!", 
                    "Błąd", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string zestaw = "";

            if (litery.Checked)
                zestaw += "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";

            if (cyfry.Checked)
                zestaw += "0123456789";

            if (specjalne.Checked)
                zestaw += "!@#$%^&*()-_=+<>?";

            if (string.IsNullOrWhiteSpace(zestaw))
            {
                MessageBox.Show("Zaznacz przynajmniej jedną grupę znaków!", 
                    "Błąd", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Random rng = new Random();
            StringBuilder generator = new StringBuilder();

            for (int i = 0; i < ileZnakow; i++)
            {
                int index = rng.Next(zestaw.Length);
                generator.Append(zestaw[index]);
            }

            aktualneHaslo = generator.ToString();

            MessageBox.Show($"Wygenerowane hasło:
{aktualneHaslo}",
                "Sukces", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void zatwierdz_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(imie.Text) ||
                string.IsNullOrWhiteSpace(nazwisko.Text) ||
                stanowisko.SelectedIndex == -1)
            {
                MessageBox.Show(
                    "Wypełnij wszystkie dane pracownika!",
                    "Błąd",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return;
            }

            string wynik =
                $"Imię: {imie.Text}
" +
                $"Nazwisko: {nazwisko.Text}
" +
                $"Stanowisko: {stanowisko.SelectedItem}
" +
                $"Hasło: {aktualneHaslo}";

            MessageBox.Show(
                $"Dodano pracownika:

{wynik}",
                "Sukces",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }

        private void groupBox1_Enter(object sender, EventArgs e) { }
        private void groupBox2_Enter(object sender, EventArgs e) { }
        private void textBox1_TextChanged(object sender, EventArgs e) { }
        private void textBox3_TextChanged(object sender, EventArgs e) { }
        private void label1_Click(object sender, EventArgs e) { }
        private void label2_Click(object sender, EventArgs e) { }
        private void label3_Click(object sender, EventArgs e) { }
        private void label4_Click(object sender, EventArgs e) { }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e) { }
    }
}
